﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    [AttributeUsage(AttributeTargets.Property)]
    class CheckUpper : Attribute, IAttribute
    {
        private string errorMessage;

        public CheckUpper(string errorMessage)
        {
            this.errorMessage = errorMessage;
        }
        #region IAttribute Implementation
        public string Message
        {
            get
            {
                return errorMessage;
            }
            set
            {
                errorMessage = value;
            }
        }

        public bool isValid(object item)
        {
            bool result = true;
            try
            {
                string s = (string)item;
                // string myname = s.Substring(0,s.Length).ToUpper();
                string myname = s;
                if (!myname.Equals(s.ToUpper()))
                    result = false;
            }
            catch (InvalidCastException)
            {
                result = false;
            }
            return result;
        }

        #endregion
    }
}
