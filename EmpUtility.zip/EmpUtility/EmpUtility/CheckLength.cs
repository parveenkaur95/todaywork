﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    [AttributeUsage(AttributeTargets.Property)]
    class CheckLength : Attribute, IAttribute
    {
        private int minChar, maxChar;
        string message;
        public CheckLength(int minChar, int maxChar , string message)
        {
            this.minChar = minChar;
            this.maxChar = maxChar;
            this.message = message;
        }
        #region IAttribute Members
        public string Message
        {
            get
            {
                return message;
            }
            set
            {
                message = value;
            }
        }

        public bool isValid(object item)
        {
            bool res = true;
            try
            {
                string s = (string)item;
               if (s.Trim().Length < minChar || s.Trim().Length > maxChar)
                    res = false;
            }
            catch (InvalidCastException)
            {
                res = false;
            }
            return res;
        }
        #endregion
    }
}
